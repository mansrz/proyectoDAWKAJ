from django.contrib import admin
from web.models import *

admin.site.register(Imagen)
admin.site.register(ImgCompartidas)
admin.site.register(AuthUser)
